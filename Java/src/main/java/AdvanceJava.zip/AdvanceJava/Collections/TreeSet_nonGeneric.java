package AdvanceJava.Collections;

import java.util.Arrays;
import java.util.TreeSet;

public class TreeSet_nonGeneric
{
    public static void main(String[] args)
    {
        TreeSet treeSet=new TreeSet(Arrays.asList("A","C","F","L","Y"));
        System.out.println(treeSet);
    }
}
