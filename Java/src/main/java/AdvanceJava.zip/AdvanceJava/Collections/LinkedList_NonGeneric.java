package AdvanceJava.Collections;

import java.util.LinkedList;

public class LinkedList_NonGeneric {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.add(1);
        list.add("Kartikey");
        list.add(2);
        list.add("Java");

        System.out.println(list);
    }
}
