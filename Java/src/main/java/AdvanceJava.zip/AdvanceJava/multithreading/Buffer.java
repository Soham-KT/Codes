package AdvanceJava.multithreading;

public interface Buffer {
    void set(int value); // place int value into Buffer

    int get(); // return int value from Buffer
}
